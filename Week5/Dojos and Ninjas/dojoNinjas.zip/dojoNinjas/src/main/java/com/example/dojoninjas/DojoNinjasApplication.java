package com.example.dojoninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoNinjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoNinjasApplication.class, args);
	}

}
