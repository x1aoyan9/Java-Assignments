public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla g = new Gorilla(100);
		
		g.throwSomething();
		g.throwSomething();
		g.throwSomething();
		
		g.eatBanana();
		g.eatBanana();
		
		g.climb();
		
	}

}
