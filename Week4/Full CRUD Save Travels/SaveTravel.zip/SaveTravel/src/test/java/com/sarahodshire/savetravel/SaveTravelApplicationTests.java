package com.sarahodshire.savetravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveTravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
